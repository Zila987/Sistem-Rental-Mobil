// Mobil mengimplementasi IdentitasKendaraan
public class Mobil implements IdentitasKendaraan {
    private String nomorPolisi;
    private String merk;
    private String warna;

    public Mobil(String nomorPolisi, String merk, String warna) {
        this.nomorPolisi = nomorPolisi;
        this.merk = merk;
        this.warna = warna;
    }

    public String getNomorPolisi() {
        return nomorPolisi;
    }

    public String getMerk() {
        return merk;
    }

    public String getWarna() {
        return warna;
    }

    @Override
    public void tampilkanIdentitas() {
        System.out.println("Mobil: " + merk + " | Warna: " + warna + " | Nomor Polisi: " + nomorPolisi);
    }
}