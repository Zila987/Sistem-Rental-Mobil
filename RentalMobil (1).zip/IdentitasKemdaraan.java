// Interface untuk identitas kendaraan
public interface IdentitasKendaraan {
    void tampilkanIdentitas();
}