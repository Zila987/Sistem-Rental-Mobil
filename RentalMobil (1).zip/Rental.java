// Rental mengatur proses peminjaman dan pengembalian mobil
public class Rental {
    private Supir supir;
    private Mobil mobil;
    private String tanggalPinjam;
    private String tanggalKembali;
    private String status;

    public void pinjamMobil(Supir supir, Mobil mobil, String tanggalPinjam) {
        this.supir = supir;
        this.mobil = mobil;
        this.tanggalPinjam = tanggalPinjam;
        this.status = "Dipinjam";

        System.out.println("\n--- MOBIL DIPINJAM ---");
        supir.tampilkanInfo();
        mobil.tampilkanIdentitas();
        System.out.println("Tanggal Pinjam: " + tanggalPinjam);
        System.out.println("Status: " + status);
    }

    public void kembalikanMobil(String tanggalKembali) {
        this.tanggalKembali = tanggalKembali;
        this.status = "Dikembalikan";

        System.out.println("\n--- MOBIL DIKEMBALIKAN ---");
        System.out.println("Tanggal Kembali: " + tanggalKembali);
        System.out.println("Status: " + status);
    }
}