// Main class untuk menjalankan program
public class Main {
    public static void main(String[] args) {
        Supir supir1 = new Supir("12345", "Budi Santoso");
        Mobil mobil1 = new Mobil("AB1234CD", "Toyota Avanza", "Hitam");

        Rental rental1 = new Rental();
        rental1.pinjamMobil(supir1, mobil1, "19 Juli 2025");
        rental1.kembalikanMobil("20 Juli 2025");
    }
    
}