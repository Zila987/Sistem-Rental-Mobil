// Abstract class sebagai dasar dari Supir
public abstract class Person {
    private String nip;
    private String nama;

    public Person(String nip, String nama) {
        this.nip = nip;
        this.nama = nama;
    }

    public String getNip() {
        return nip;
    }

    public String getNama() {
        return nama;
    }

    public abstract void tampilkanInfo();
}