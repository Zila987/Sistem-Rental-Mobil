// Supir mewarisi Person
public class Supir extends Person {
    public Supir(String nip, String nama) {
        super(nip, nama);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Supir: " + getNama() + " | NIP: " + getNip());
    }
}